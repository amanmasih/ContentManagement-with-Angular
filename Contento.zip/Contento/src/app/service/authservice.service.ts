import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Gettingdata } from './gettingdata';

@Injectable({
  providedIn: 'root'
})
export class AuthserviceService {

  constructor(private httpclient:HttpClient) { }
  api_url='http://localhost:8090/api/v1/register'

  add(userData: Gettingdata): Observable<Object>{
    return this.httpclient.post<Gettingdata>(this.api_url,userData);

  }
  public register(user:Gettingdata){
    return this.httpclient.post(`${this.api_url}`,user);
  }
  get(): Observable<Array<Gettingdata>> {
    return this.httpclient.get<Array<Gettingdata>>(this.api_url)
  }
}


