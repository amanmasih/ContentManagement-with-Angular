import { Gettingdata } from './gettingdata';

describe('Gettingdata', () => {
  it('should create an instance', () => {
    expect(new Gettingdata()).toBeTruthy();
  });
});
