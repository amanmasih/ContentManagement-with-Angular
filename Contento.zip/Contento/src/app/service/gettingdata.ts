export class Gettingdata {
    constructor(
    public userid: string,
    public userName: string,
    public password:string
    )
    {}

}

