export class User {
  userId!:string;
  userName!:string;
  password!:string;
}
