import { Component, OnInit } from '@angular/core';
import { RegisterService } from '../register.service';
import { User } from '../user';

@Component({
  selector: 'app-userlogin',
  templateUrl: './userlogin.component.html',
  styleUrls: ['./userlogin.component.css']
})
export class UserloginComponent implements OnInit {
  user:User =new User()
  constructor(private registerService: RegisterService) { }

  ngOnInit(): void {
  }
  userlogin(){
    console.log(this.user)
    this.registerService.loginUser(this.user)
    .subscribe(data=>{
      alert("Successfully User is registered....")
     },error=>alert("Sorry User not register"));
  }
}

