import { ComponentFixture, TestBed } from '@angular/core/testing';

import { KeepnoteLayoutComponent } from './keepnote-layout.component';

describe('KeepnoteLayoutComponent', () => {
  let component: KeepnoteLayoutComponent;
  let fixture: ComponentFixture<KeepnoteLayoutComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ KeepnoteLayoutComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(KeepnoteLayoutComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
