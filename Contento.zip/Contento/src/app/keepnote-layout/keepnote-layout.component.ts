import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
@Component({
  selector: 'app-keepnote-layout',
  templateUrl: './keepnote-layout.component.html',
  styleUrls: ['./keepnote-layout.component.css']
})
export class KeepnoteLayoutComponent implements OnInit {

  constructor(public httpclient: HttpClient) { }

  ngOnInit(): void {
  }
  totalwidth="";
  columnno="";
  width="";
  texttitle="";
  text="";
  data:any;
 
  postingdata={
    title:this.texttitle,
    description:this.text
  };

  getdata(){
    this.httpclient.get<any[]>("http://localhost:3000/data").subscribe(data=>{
      this.data=data;
      let maindiv= document.getElementsByClassName("container") as HTMLCollectionOf<HTMLElement>
      maindiv[0].style.display='block'
      maindiv[0].style.columns=this.columnno;
      maindiv[0].style.width=this.totalwidth;
      for(let i=0;i<data.length;i++)
      {
        let div1=<HTMLDivElement>(document.createElement('div'));
        let h1=<HTMLDivElement>(document.createElement('h4'));
        let p1=<HTMLDivElement>(document.createElement('p'));
        div1.classList.add('box');
        div1.style.marginBottom= '10px';
        div1.style.backgroundColor='wheat';
        div1.style.borderRadius= '5px';
      div1.style.position= 'relative';
        div1.style.breakInside='avoid';
        h1.innerHTML=this.data[i].title;
        p1.innerHTML=this.data[i].description;
        div1.appendChild(h1);
        div1.appendChild(p1);
        maindiv[0].appendChild(div1);
        let b= document.getElementsByClassName("box") as HTMLCollectionOf<HTMLElement>
        for(let i=0;i<b.length;i++){
          b[i].style.width=this.width;
        }
      }
    },
    error=>{

    }
    );
  }
  postdata(){
    this.postingdata={
      title:this.texttitle,
      description:this.text
    }
    if(this.texttitle!=""){
    this.httpclient.post<any[]>("http://localhost:3000/data",this.postingdata).subscribe(data=>{
     
      console.log(data);
    
    },
    error=>{

    }
    );
  }
  else{
console.log("sorry");
  }
  }
}
